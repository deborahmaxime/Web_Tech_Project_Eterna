// ========== SLIDESHOW FUNCTIONALITY ==========
const memoryImages = [
  "https://images.unsplash.com/photo-1501854140801-50d01698950b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
  "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
  "https://images.unsplash.com/photo-1469474968028-56623f02e42e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
  "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
  "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80"
];

let currentIndex = 0;

function initializeSlideshow() {
  const slideshow = document.getElementById('memory-slideshow');
  if (!slideshow) return;

  // Create slides
  memoryImages.forEach((src, i) => {
    const slide = document.createElement('div');
    slide.className = 'slide';
    slide.style.backgroundImage = `url(${src})`;
    if (i === 0) slide.classList.add('active');
    slideshow.appendChild(slide);
  });

  // Auto-rotate slideshow
  setInterval(() => {
    const slides = document.querySelectorAll('.slide');
    if (slides.length === 0) return;
    
    slides[currentIndex].classList.remove('active');
    currentIndex = (currentIndex + 1) % slides.length;
    slides[currentIndex].classList.add('active');
  }, 5000);
}

// ========== PAGE NAVIGATION ==========
function showPage(pageId) {
  // Remove active class from all pages
  document.querySelectorAll('.page').forEach(page => {
    page.classList.remove('active');
  });
  
  // Add active class to selected page
  const targetPage = document.getElementById(pageId);
  if (targetPage) {
    targetPage.classList.add('active');
  }
  
  // Update navigation active state
  document.querySelectorAll('.nav-links a').forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('onclick')?.includes(pageId)) {
      link.classList.add('active');
    }
  });
  
  // Scroll to top
  window.scrollTo(0, 0);
  
  // Store current page in sessionStorage
  sessionStorage.setItem('currentPage', pageId);
}

// ========== FORM HANDLERS ==========
function handleLogin(event) {
  event.preventDefault();
  
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPass').value;
  
  // Basic validation
  if (!email || !password) {
    alert('Please fill in all fields');
    return;
  }
  
  // Store user info (in real app, this would be server-side)
  sessionStorage.setItem('userEmail', email);
  sessionStorage.setItem('isLoggedIn', 'true');
  
  // Extract name from email for personalization
  const userName = email.split('@')[0];
  sessionStorage.setItem('userName', userName);
  
  // Show success message
  showNotification('Welcome back! Logging you in...', 'success');
  
  // Navigate to dashboard
  setTimeout(() => {
    updateUserName();
    showPage('dashboard');
  }, 1000);
}

function handleSignup(event) {
  event.preventDefault();
  
  const firstName = document.getElementById('firstName').value;
  const lastName = document.getElementById('lastName').value;
  const email = document.getElementById('signupEmail').value;
  const password = document.getElementById('signupPass').value;
  const confirmPassword = document.getElementById('confirmPass').value;
  
  // Validation
  if (!firstName || !lastName || !email || !password || !confirmPassword) {
    showNotification('Please fill in all fields', 'error');
    return;
  }
  
  if (password !== confirmPassword) {
    showNotification('Passwords do not match', 'error');
    return;
  }
  
  if (password.length < 6) {
    showNotification('Password must be at least 6 characters', 'error');
    return;
  }
  
  // Store user info
  sessionStorage.setItem('userName', firstName);
  sessionStorage.setItem('userEmail', email);
  sessionStorage.setItem('isLoggedIn', 'true');
  
  // Show success message
  showNotification('Account created successfully! Welcome to ETERNA! ✨', 'success');
  
  // Navigate to dashboard
  setTimeout(() => {
    updateUserName();
    showPage('dashboard');
  }, 1500);
}

function handleCreateMemory(event) {
  event.preventDefault();
  
  const title = document.getElementById('memTitle').value;
  const date = document.getElementById('memDate').value;
  const location = document.getElementById('memLocation').value;
  const text = document.getElementById('memText').value;
  const privacy = document.getElementById('memPrivacy').value;
  
  // Validation
  if (!title || !date || !text) {
    showNotification('Please fill in required fields', 'error');
    return;
  }
  
  // In a real app, this would save to database
  const memory = {
    id: Date.now(),
    title,
    date,
    location,
    text,
    privacy,
    createdAt: new Date().toISOString()
  };
  
  // Store in sessionStorage (temporary)
  const memories = JSON.parse(sessionStorage.getItem('memories') || '[]');
  memories.push(memory);
  sessionStorage.setItem('memories', JSON.stringify(memories));
  
  // Show success message
  showNotification('✨ Memory saved to your capsule!', 'success');
  
  // Reset form
  document.getElementById('createMemoryForm').reset();
  
  // Navigate to view page
  setTimeout(() => {
    showPage('view');
  }, 1500);
}

// ========== FILTER FUNCTIONALITY ==========
function filterMemories(filter) {
  const cards = document.querySelectorAll('.memory-card');
  const filterBtns = document.querySelectorAll('.filter-btn');
  
  // Update active button
  filterBtns.forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
  
  // Filter cards
  cards.forEach(card => {
    const badge = card.querySelector('.badge');
    const cardType = badge?.textContent.toLowerCase() || '';
    
    if (filter === 'all') {
      card.style.display = 'block';
    } else if (cardType.includes(filter)) {
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
}

// ========== UTILITY FUNCTIONS ==========
function updateUserName() {
  const userName = sessionStorage.getItem('userName') || 'Traveler';
  const userNameElement = document.getElementById('userName');
  if (userNameElement) {
    userNameElement.textContent = userName;
  }
}

function showNotification(message, type = 'info') {
  // Create notification element
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed;
    top: 80px;
    right: 20px;
    background: ${type === 'success' ? '#4caf50' : type === 'error' ? '#f44336' : '#2196f3'};
    color: white;
    padding: 1rem 1.5rem;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    z-index: 10000;
    animation: slideIn 0.3s ease;
    max-width: 350px;
  `;
  notification.textContent = message;
  
  // Add to page
  document.body.appendChild(notification);
  
  // Remove after 3 seconds
  setTimeout(() => {
    notification.style.animation = 'slideOut 0.3s ease';
    setTimeout(() => {
      document.body.removeChild(notification);
    }, 300);
  }, 3000);
}

// ========== AUTHENTICATION CHECK ==========
function checkAuthentication() {
  const isLoggedIn = sessionStorage.getItem('isLoggedIn') === 'true';
  const currentPage = sessionStorage.getItem('currentPage') || 'home';
  
  // Protected pages
  const protectedPages = ['dashboard', 'create', 'view', 'timeline'];
  
  if (protectedPages.includes(currentPage) && !isLoggedIn) {
    showPage('login');
    showNotification('Please log in to access this page', 'error');
  } else {
    showPage(currentPage);
  }
}

// ========== SCROLL EFFECTS ==========
let lastScrollTop = 0;
window.addEventListener('scroll', () => {
  const nav = document.getElementById('mainNav');
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  
  if (scrollTop > lastScrollTop && scrollTop > 100) {
    // Scrolling down
    nav.style.transform = 'translateY(-100%)';
  } else {
    // Scrolling up
    nav.style.transform = 'translateY(0)';
  }
  
  lastScrollTop = scrollTop;
});

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', (e) => {
  // ESC to go back to dashboard
  if (e.key === 'Escape') {
    const currentPage = document.querySelector('.page.active')?.id;
    if (currentPage !== 'home' && currentPage !== 'dashboard') {
      showPage('dashboard');
    }
  }
  
  // Ctrl/Cmd + N to create new memory
  if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
    e.preventDefault();
    if (sessionStorage.getItem('isLoggedIn') === 'true') {
      showPage('create');
    }
  }
});

// ========== LOGO CLICK HANDLER ==========
document.addEventListener('DOMContentLoaded', () => {
  const logo = document.querySelector('.logo');
  if (logo) {
    logo.addEventListener('click', () => {
      showPage('home');
    });
  }
});
// Add to the showPage function in eterna.js (if not already there)
function showPage(pageId) {
  // Remove active class from all pages
  document.querySelectorAll('.page').forEach(page => {
    page.classList.remove('active');
  });
  
  // Add active class to selected page
  const targetPage = document.getElementById(pageId);
  if (targetPage) {
    targetPage.classList.add('active');
  }
  
  // Update navigation active state
  document.querySelectorAll('.nav-links a').forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('href')?.includes(pageId) || 
        link.getAttribute('onclick')?.includes(pageId)) {
      link.classList.add('active');
    }
  });
  
  // Scroll to top
  window.scrollTo(0, 0);
  
  // Store current page in sessionStorage
  sessionStorage.setItem('currentPage', pageId);
}

// ========== INITIALIZE ON LOAD ==========
window.addEventListener('DOMContentLoaded', () => {
  // Initialize slideshow
  initializeSlideshow();
  
  // Update user name if logged in
  updateUserName();
  
  // Check authentication and restore page
  checkAuthentication();
  
  // Add CSS for notifications
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from {
        transform: translateX(400px);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
    
    @keyframes slideOut {
      from {
        transform: translateX(0);
        opacity: 1;
      }
      to {
        transform: translateX(400px);
        opacity: 0;
      }
    }
  `;
  document.head.appendChild(style);
});

// ========== EXPORT FUNCTIONS FOR GLOBAL USE ==========
window.showPage = showPage;
window.handleLogin = handleLogin;
window.handleSignup = handleSignup;
window.handleCreateMemory = handleCreateMemory;
window.filterMemories = filterMemories;