<?php
session_start();
$user_name = isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Help & Support - ETERNA</title>
  <link rel="icon" type="image/png" href="../Media/ETERNA2-removebg-preview.png">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;1,400&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../css_files/eterna.css">
</head>
<body>

  <!-- Navigation -->
  <nav id="mainNav">
    <div class="logo">ETERNA</div>
    <div class="nav-links">
      <a href="home.php" class="nav-link">Home</a>
      <a href="about.php" class="nav-link">About</a>
      <a href="dashboard.php" class="nav-link">Dashboard</a>
      <a href="Team.php" class="nav-link">Our Team</a>
      <a href="help.php" class="nav-link active">Help</a>
    </div>
    <div class="nav-auth">
      <?php if($user_name): ?>
        <span>Welcome, <?php echo $user_name; ?>!</span>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Log out</a>
      <?php else: ?>
        <a href="login.php"><i class="fas fa-sign-in-alt"></i> Log in</a>
        <a href="signup.php"><i class="fas fa-user-plus"></i> Sign up</a>
      <?php endif; ?>
    </div>
  </nav>

  <!-- Help Page -->
  <section id="help" class="page active">
    <div class="page-content">
      <div class="illustration">❓</div>
      <h1>Help & Support</h1>
      <p>We're here for you</p>
      
      <div class="card">
        <details class="faq-item">
          <summary><i class="fas fa-question-circle"></i> How do I create a time capsule?</summary>
          <p>After signing up, go to your Dashboard and click "Create Memory". Add text, photos, or voice — then save!</p>
        </details>
        <details class="faq-item">
          <summary><i class="fas fa-question-circle"></i> Can I send a message to my future self?</summary>
          <p>Yes! When creating a memory, choose "Future message" and set an unlock date. We'll notify you when it's time.</p>
        </details>
        <details class="faq-item">
          <summary><i class="fas fa-question-circle"></i> Is my data private?</summary>
          <p>Absolutely. All memories are encrypted. Only you (or people you share with) can access them.</p>
        </details>
        <details class="faq-item">
          <summary><i class="fas fa-question-circle"></i> How do I share memories with others?</summary>
          <p>Click on any memory card and select the share button. You can invite collaborators via email.</p>
        </details>
      </div>

      <p style="margin-top: 2rem; font-weight: 500;">Still need help?</p>
      <button class="btn btn-primary"><i class="fas fa-envelope"></i> Contact Support</button>
    </div>
  </section>

  <footer>
    <p>ETERNA — Where moments last forever.</p>
    <div class="footer-links">
      <a href="about.php">About</a>
      <a href="Team.php">Our Team</a>
      <a href="help.php">Help</a>
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
    </div>
  </footer>

  <script src="../js_files/eterna.js"></script>
</body>
</html>
