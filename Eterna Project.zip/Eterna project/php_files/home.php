<?php
session_start();
if(!isset($_SESSION['user_email'])){
    header("Location: login.php");
    exit();
}
$user_name = htmlspecialchars($_SESSION['user_name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>ETERNA — Where moments last forever.</title>
  <link rel="icon" type="image/png" href="../Media/ETERNA2-removebg-preview.png">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;1,400&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../css_files/eterna.css">
</head>
<body>

  <!-- Navigation -->
  <nav id="mainNav">
    <div class="logo">ETERNA</div>
    <div class="nav-links">
      <a href="home.php" class="nav-link active">Home</a>
      <a href="about.php" class="nav-link">About</a>
      <a href="dashboard.php" class="nav-link">Dashboard</a>
      <a href="Team.php" class="nav-link">Our Team</a>
      <a href="help.php" class="nav-link">Help</a>
    </div>
    <div class="nav-auth">
      <span>Welcome, <?php echo $user_name; ?>!</span>
      <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Log out</a>
    </div>
  </nav>

  <!-- Home Page with Slideshow -->
  <section id="home" class="page active">
    <div class="slideshow" id="memory-slideshow"></div>
    <div class="page-content hero-content">
      <div class="illustration animate-fade-in">🕰️</div>
      <h1 class="welcome-text animate-fade-in">Welcome to ETERNA, <?php echo $user_name; ?>!</h1>
      <p class="hero-subtitle animate-fade-in">Where moments last forever. Preserve your memories in a digital time capsule — beautifully, securely, and with love.</p>
      
      <div class="hero-actions animate-fade-in">
        <button class="btn btn-primary" onclick="window.location.href='dashboard.php'">
          <i class="fas fa-user-plus"></i> View Your Capsule
        </button>
      </div>

      <div class="panels">
        <div class="panel" onclick="window.location.href='dashboard.php'">
          <h3>Your Latest Memory</h3>
          <div class="memory-preview">
            <i class="fas fa-image"></i>
            <p>Sunset at Lake Tahoe • Oct 12, 2025</p>
          </div>
          <button class="btn btn-sm">View Memory</button>
        </div>

        <div class="panel panel-portal" onclick="window.location.href='view_capsule.php'">
          <h3>Open My Capsule</h3>
          <div class="capsule-portal">
            <span class="portal-icon">✨</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <footer>
    <p>ETERNA — Where moments last forever.</p>
    <div class="footer-links">
      <a href="about.php">About</a>
      <a href="Team.php">Our Team</a>
      <a href="help.php">Help</a>
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
    </div>
  </footer>

  <script src="../js_files/eterna.js"></script>
</body>
</html>
