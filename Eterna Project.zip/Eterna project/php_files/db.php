<?php
$servername = "localhost";
$username   = "root";
$password   = "";
$database   = "eternaDb";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if($conn->connect_error){
    die("Database Connection Failed: " . $conn->connect_error);
}
?>
