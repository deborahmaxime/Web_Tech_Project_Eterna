<?php
session_start();

// Redirect to login if not logged in
if(!isset($_SESSION['user_name'])){
    header("Location: login.php");
    exit();
}

$user_name = htmlspecialchars($_SESSION['user_name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>My Capsule - ETERNA</title>
  <link rel="icon" type="image/png" href="../Media/ETERNA2-removebg-preview.png">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;1,400&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../css_files/eterna.css">
</head>
<body>

  <!-- Navigation -->
  <nav id="mainNav">
    <div class="logo">ETERNA</div>
    <div class="nav-links">
      <a href="home.php" class="nav-link">Home</a>
      <a href="about.php" class="nav-link">About</a>
      <a href="dashboard.php" class="nav-link">Dashboard</a>
      <a href="Team.php" class="nav-link">Our Team</a>
      <a href="help.php" class="nav-link">Help</a>
    </div>
    <div class="nav-auth">
      <span>Welcome, <?php echo $user_name; ?>!</span>
      <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Log out</a>
    </div>
  </nav>

  <!-- View Capsule Page -->
  <section id="view" class="page active">
    <div class="page-content">
      <div class="illustration">📚</div>
      <h1>My Time Capsule</h1>
      <p>All your memories, preserved with care</p>
      
      <div class="filter-bar">
        <button class="filter-btn active" onclick="filterMemories('all')">All</button>
        <button class="filter-btn" onclick="filterMemories('private')">Private</button>
        <button class="filter-btn" onclick="filterMemories('shared')">Shared</button>
        <button class="filter-btn" onclick="filterMemories('future')">Future</button>
      </div>

      <div class="grid" id="memoriesGrid">
        <!-- Example memory cards; in future, fetch dynamically from DB -->
        <div class="memory-card">
          <div class="card-img">
            <i class="fas fa-sun card-icon"></i>
          </div>
          <div class="card-content">
            <h4>Mountain Sunrise</h4>
            <p class="card-date"><i class="fas fa-calendar"></i> Aug 12, 2024</p>
            <p class="card-desc">Reached the peak with Maya at dawn.</p>
            <span class="badge badge-private">Private</span>
          </div>
          <div class="card-actions">
            <button class="action-btn" title="Edit"><i class="fas fa-edit"></i></button>
            <button class="action-btn" title="Share"><i class="fas fa-share-alt"></i></button>
            <button class="action-btn" title="Delete"><i class="fas fa-trash"></i></button>
          </div>
        </div>

        <div class="memory-card">
          <div class="card-img">
            <i class="fas fa-film card-icon"></i>
          </div>
          <div class="card-content">
            <h4>Birthday Celebration</h4>
            <p class="card-date"><i class="fas fa-calendar"></i> May 20, 2025</p>
            <p class="card-desc">Surrounded by laughter and old friends.</p>
            <span class="badge badge-future">Future</span>
          </div>
          <div class="card-actions">
            <button class="action-btn" title="Edit"><i class="fas fa-edit"></i></button>
            <button class="action-btn" title="Share"><i class="fas fa-user-friends"></i></button>
            <button class="action-btn" title="Delete"><i class="fas fa-trash"></i></button>
          </div>
        </div>

        <div class="memory-card">
          <div class="card-img">
            <i class="fas fa-music card-icon"></i>
          </div>
          <div class="card-content">
            <h4>Concert Night</h4>
            <p class="card-date"><i class="fas fa-calendar"></i> Feb 3, 2023</p>
            <p class="card-desc">The night music felt like home.</p>
            <span class="badge badge-shared">Shared</span>
          </div>
          <div class="card-actions">
            <button class="action-btn" title="Edit"><i class="fas fa-edit"></i></button>
            <button class="action-btn" title="Share"><i class="fas fa-share-alt"></i></button>
            <button class="action-btn" title="Delete"><i class="fas fa-trash"></i></button>
          </div>
        </div>
      </div>

      <button class="btn btn-primary" onclick="window.location.href='create_memory.php'" style="margin-top: 2rem;">
        <i class="fas fa-plus"></i> Add Another Memory
      </button>
    </div>
    
    <div class="floating-btn" onclick="window.location.href='create_memory.php'" title="Create new memory">
      <i class="fas fa-plus"></i>
    </div>
  </section>

  <footer>
    <p>ETERNA — Where moments last forever.</p>
    <div class="footer-links">
      <a href="about.php">About</a>
      <a href="Team.php">Our Team</a>
      <a href="help.php">Help</a>
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
    </div>
  </footer>

  <script src="../js_files/eterna.js"></script>
</body>
</html>
