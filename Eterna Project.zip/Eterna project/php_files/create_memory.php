<?php
session_start();

// Redirect to login if user not logged in
if(!isset($_SESSION['user_name'])){
    header("Location: login.php");
    exit();
}

$user_name = htmlspecialchars($_SESSION['user_name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Create Memory - ETERNA</title>
  <link rel="icon" type="image/png" href="../Media/ETERNA2-removebg-preview.png">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;1,400&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../css_files/eterna.css">
</head>
<body>

  <!-- Navigation -->
  <nav id="mainNav">
    <div class="logo">ETERNA</div>
    <div class="nav-links">
      <a href="home.php" class="nav-link">Home</a>
      <a href="about.php" class="nav-link">About</a>
      <a href="dashboard.php" class="nav-link">Dashboard</a>
      <a href="Team.php" class="nav-link">Our Team</a>
      <a href="help.php" class="nav-link">Help</a>
    </div>
    <div class="nav-auth">
      <span>Welcome, <?php echo $user_name; ?>!</span>
      <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Log out</a>
    </div>
  </nav>

  <!-- Create Memory Page -->
  <section id="create" class="page active">
    <div class="page-content">
      <div class="illustration">✍️</div>
      <h1>Create a New Memory</h1>
      <p>Preserve a moment that matters</p>
      
      <div class="card form-card">
        <form id="createMemoryForm" method="POST" action="process_memory.php" enctype="multipart/form-data">
          <div class="form-group">
            <label for="memTitle"><i class="fas fa-bookmark"></i> Title</label>
            <input type="text" id="memTitle" name="title" placeholder="e.g., Our Wedding Day" required>
          </div>
          
          <div class="form-group">
            <label for="memDate"><i class="fas fa-calendar"></i> Date</label>
            <input type="date" id="memDate" name="memory_date" required>
          </div>

          <div class="form-group">
            <label for="memLocation"><i class="fas fa-map-marker-alt"></i> Location</label>
            <input type="text" id="memLocation" name="location" placeholder="e.g., Paris, France">
          </div>
          
          <div class="form-group">
            <label for="memText"><i class="fas fa-book"></i> Your Story</label>
            <textarea id="memText" name="story_text" placeholder="Write what you felt, saw, heard..." required></textarea>
          </div>
          
          <div class="form-group">
            <label for="memMedia"><i class="fas fa-camera"></i> Add Media</label>
            <input type="file" id="memMedia" name="media_files[]" accept="image/*,video/*,audio/*" multiple>
            <small>Supports photos, videos, and voice notes</small>
          </div>
          
          <div class="form-group">
            <label for="memPrivacy"><i class="fas fa-shield-alt"></i> Privacy</label>
            <select id="memPrivacy" name="privacy">
              <option value="Private">Private</option>
              <option value="Shared">Shared with collaborators</option>
              <option value="Future">Future message (set unlock date)</option>
            </select>
          </div>

          <div class="form-actions">
            <button type="submit" class="btn btn-primary">
              <i class="fas fa-save"></i> Save Memory
            </button>
            <button type="button" class="btn btn-outline" onclick="window.location.href='dashboard.php'">
              <i class="fas fa-times"></i> Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  </section>

  <footer>
    <p>ETERNA — Where moments last forever.</p>
    <div class="footer-links">
      <a href="about.php">About</a>
      <a href="Team.php">Our Team</a>
      <a href="help.php">Help</a>
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
    </div>
  </footer>

  <script src="../js_files/eterna.js"></script>
</body>
</html>
