<?php
session_start();
$user_name = isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Our Team - ETERNA</title>
  <link rel="icon" type="image/png" href="../Media/ETERNA2-removebg-preview.png">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;1,400&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../css_files/eterna.css">
</head>
<body>

  <!-- Navigation -->
  <nav id="mainNav">
    <div class="logo">ETERNA</div>
    <div class="nav-links">
      <a href="home.php" class="nav-link">Home</a>
      <a href="about.php" class="nav-link">About</a>
      <a href="dashboard.php" class="nav-link">Dashboard</a>
      <a href="Team.php" class="nav-link active">Our Team</a>
      <a href="help.php" class="nav-link">Help</a>
    </div>
    <div class="nav-auth">
      <?php if($user_name): ?>
        <span>Welcome, <?php echo $user_name; ?>!</span>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Log out</a>
      <?php else: ?>
        <a href="login.php"><i class="fas fa-sign-in-alt"></i> Log in</a>
        <a href="signup.php"><i class="fas fa-user-plus"></i> Sign up</a>
      <?php endif; ?>
    </div>
  </nav>

  <!-- Team Page -->
  <section id="team" class="page active">
    <div class="page-content">
      <div class="illustration">👥</div>
      <h1>Meet Our Team</h1>
      <p>The passionate creators behind ETERNA</p>
      
      <div class="team-container">
        <div class="member">
          <img src="https://static.wixstatic.com/media/642103_b1650310218c43c8ad63151bb7ed25a5~mv2.jpg" alt="Deborah Cholabomi Agossou">
          <h3>Deborah Cholabomi Agossou</h3>
          <p>Database Developer</p>
        </div>

        <div class="member">
          <img src="https://static.wixstatic.com/media/642103_65f91d43d1f14748a45a640e2450cce8~mv2.jpg" alt="Kevin Bigirimana">
          <h3>Kevin Bigirimana</h3>
          <p>Back-end Developer</p>
        </div>

        <div class="member">
          <img src="https://static.wixstatic.com/media/642103_48cbc4169ca34700a8afaa18c1b2d7a2~mv2.jpg" alt="Ramatou Salah Hassane">
          <h3>Ramatou Salah Hassane</h3>
          <p>UI/UX Designer</p>
        </div>

        <div class="member">
          <img src="https://static.wixstatic.com/media/642103_102a864036964f8080c36f0250eac909~mv2.jpg" alt="Ousmane Boubacar Bako">
          <h3>Ousmane Boubacar Bako</h3>
          <p>Front-end Developer</p>
        </div>
      </div>
    </div>
  </section>

  <footer>
    <p>ETERNA — Where moments last forever.</p>
    <div class="footer-links">
      <a href="about.php">About</a>
      <a href="Team.php">Our Team</a>
      <a href="help.php">Help</a>
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
    </div>
  </footer>

  <script src="../js_files/eterna.js"></script>
</body>
</html>
