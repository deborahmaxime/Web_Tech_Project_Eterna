<?php
session_start();
$user_name = isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>ETERNA — Where moments last forever.</title>
  <link rel="icon" type="image/png" href="../Media/ETERNA2-removebg-preview.png">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;1,400&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../css_files/eterna.css">
</head>
<body>

  <!-- Navigation -->
  <nav id="mainNav">
    <div class="logo">ETERNA</div>
    <div class="nav-links">
      <a href="home.php" class="nav-link">Home</a>
      <a href="about.php" class="nav-link active">About</a>
      <a href="dashboard.php" class="nav-link">Dashboard</a>
      <a href="Team.php" class="nav-link">Our Team</a>
      <a href="help.php" class="nav-link">Help</a>
    </div>
    <div class="nav-auth">
      <?php if($user_name): ?>
        <span>Welcome, <?php echo $user_name; ?>!</span>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Log out</a>
      <?php else: ?>
        <a href="login.php"><i class="fas fa-sign-in-alt"></i> Log in</a>
        <a href="signup.php"><i class="fas fa-user-plus"></i> Sign up</a>
      <?php endif; ?>
    </div>
  </nav>

  <!-- About Page -->
  <section id="about" class="page active">
    <div class="page-content">
      <div class="illustration">✨</div>
      <h1>Our Story</h1>
      <p>Created by dreamers and memory-keepers, ETERNA was born from a simple wish: to never lose what matters most. In today's digital age, people store photos and videos across multiple platforms, but these memories become disorganized over time. The stories behind the photos are often forgotten.</p>
      
      <div class="grid">
        <div class="tile">
          <i class="fas fa-heart"></i>
          <h3>Emotional Design</h3>
          <p>Calm, warm, and intimate — like opening an old journal.</p>
        </div>
        <div class="tile">
          <i class="fas fa-lock"></i>
          <h3>Private & Secure</h3>
          <p>Your memories stay yours — encrypted and protected.</p>
        </div>
        <div class="tile">
          <i class="fas fa-clock"></i>
          <h3>Time-Locked</h3>
          <p>Send messages to your future self — or loved ones.</p>
        </div>
        <div class="tile">
          <i class="fas fa-timeline"></i>
          <h3>Interactive Timeline</h3>
          <p>Organize memories chronologically in beautiful capsules.</p>
        </div>
      </div>
    </div>
  </section>

  <footer>
    <p>ETERNA — Where moments last forever.</p>
    <div class="footer-links">
      <a href="about.php">About</a>
      <a href="Team.php">Our Team</a>
      <a href="help.php">Help</a>
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
    </div>
  </footer>

  <script src="../js_files/eterna.js"></script>
</body>
</html>
