<?php
session_start();
require "db.php";

if(isset($_POST['register'])){
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];

    // --- VALIDATION ---
    if(empty($first_name) || empty($last_name) || empty($email) || empty($password) || empty($confirm)){
        $error = "Please fill all fields";
    } 
    elseif($password !== $confirm){
        $error = "Passwords do not match";
    }
    else {
        // Check if email already exists
        $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
        if(!$stmt){
            die("SQL ERROR: " . $conn->error);
        }
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if($stmt->num_rows > 0){
            $error = "Email already exists";
        } else {
            // Hash password
            $hash = password_hash($password, PASSWORD_DEFAULT);

            // Insert user
            $insert = $conn->prepare("INSERT INTO users(first_name, last_name, email, password_hash) VALUES (?, ?, ?, ?)");
            if(!$insert){
                die("SQL ERROR: " . $conn->error);
            }
            $insert->bind_param("ssss", $first_name, $last_name, $email, $hash);
            $insert->execute();

            // Auto-login
            $_SESSION['user_email'] = $email;
            $_SESSION['user_name'] = $first_name;
            header("Location: home.php");
            exit();
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Eterna</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f5f5f5; }
        .container { max-width: 400px; margin: 50px auto; background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1);}
        h2 { text-align: center; margin-bottom: 20px; }
        input[type=text], input[type=email], input[type=password] { width: 100%; padding: 10px; margin: 5px 0 15px 0; border-radius: 5px; border: 1px solid #ccc; }
        button { width: 100%; padding: 10px; background: #007BFF; color: #fff; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .error { color: red; text-align: center; margin-bottom: 10px; }
        .login-link { text-align: center; margin-top: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Create Account</h2>
        <?php if(isset($error)) { echo "<div class='error'>$error</div>"; } ?>
        <form action="signup.php" method="POST">
            <input type="text" name="first_name" placeholder="First Name" required>
            <input type="text" name="last_name" placeholder="Last Name" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm" placeholder="Confirm Password" required>
            <button type="submit" name="register">Sign Up</button>
        </form>
        <div class="login-link">
            Already have an account? <a href="login.php">Login</a>
        </div>
    </div>
</body>
</html>
