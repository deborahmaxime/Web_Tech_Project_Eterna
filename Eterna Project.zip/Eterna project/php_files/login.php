<?php
session_start();
require "db.php";

if(isset($_POST['login'])){
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if(empty($email) || empty($password)){
        $error = "Please fill all fields";
    } else {
        $stmt = $conn->prepare("SELECT user_id, first_name, password_hash FROM users WHERE email = ?");
        if(!$stmt){
            die("SQL ERROR: " . $conn->error);
        }
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if($stmt->num_rows == 1){
            $stmt->bind_result($user_id, $first_name, $hash);
            $stmt->fetch();

            if(password_verify($password, $hash)){
                // Login success
                $_SESSION['user_email'] = $email;
                $_SESSION['user_name'] = $first_name;
                $_SESSION['user_id'] = $user_id;

                // Redirect to home page
                header("Location: home.php");
                exit();
            } else {
                $error = "Invalid password";
            }
        } else {
            $error = "Email not registered";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - Eterna</title>
<style>
    body { font-family: Arial, sans-serif; background: #f5f5f5; }
    .container { max-width: 400px; margin: 50px auto; background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1);}
    h2 { text-align: center; margin-bottom: 20px; }
    input[type=email], input[type=password] { width: 100%; padding: 10px; margin: 5px 0 15px 0; border-radius: 5px; border: 1px solid #ccc; }
    button { width: 100%; padding: 10px; background: #28a745; color: #fff; border: none; border-radius: 5px; cursor: pointer; }
    button:hover { background: #218838; }
    .error { color: red; text-align: center; margin-bottom: 10px; }
    .signup-link { text-align: center; margin-top: 15px; }
</style>
</head>
<body>
<div class="container">
    <h2>Login</h2>
    <?php if(isset($error)) { echo "<div class='error'>$error</div>"; } ?>
    <form action="" method="POST">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" name="login">Login</button>
    </form>
    <div class="signup-link">
        Don't have an account? <a href="signup.php">Sign Up</a>
    </div>
</div>
</body>
</html>
