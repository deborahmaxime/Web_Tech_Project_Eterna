<?php
session_start();
if(!isset($_SESSION['user_email'])){
    header("Location: login.php");
    exit();
}
$user_name = htmlspecialchars($_SESSION['user_name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>ETERNA — Your Dashboard</title>
  <link rel="icon" type="image/png" href="../Media/ETERNA2-removebg-preview.png">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;1,400&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../css_files/eterna.css">
</head>
<body>

  <!-- Navigation -->
  <nav id="mainNav">
    <div class="logo">ETERNA</div>
    <div class="nav-links">
      <a href="home.php" class="nav-link">Home</a>
      <a href="about.php" class="nav-link">About</a>
      <a href="dashboard.php" class="nav-link active">Dashboard</a>
      <a href="Team.php" class="nav-link">Our Team</a>
      <a href="help.php" class="nav-link">Help</a>
    </div>
    <div class="nav-auth">
      <span>Welcome, <?php echo $user_name; ?>!</span>
      <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Log out</a>
    </div>
  </nav>

  <!-- Dashboard -->
  <section id="dashboard" class="page active">
    <div class="page-content dashboard-content">
      <div class="dashboard-header">
        <div>
          <div class="illustration">📦</div>
          <h1>Welcome back, <?php echo $user_name; ?>!</h1>
          <p>Your personal memory hub</p>
        </div>
      </div>
      
      <div class="grid">
        <div class="tile tile-clickable" onclick="window.location.href='create_memory.php'">
          <i class="fas fa-plus-circle"></i>
          <h3>Create Memory</h3>
          <p>Add photos, videos, or voice notes</p>
        </div>
        <div class="tile tile-clickable" onclick="window.location.href='view_capsule.php'">
          <i class="fas fa-book"></i>
          <h3>View Capsule</h3>
          <p>Explore all your saved moments</p>
        </div>
        <div class="tile tile-clickable" onclick="window.location.href='timeline.php'">
          <i class="fas fa-timeline"></i>
          <h3>Timeline View</h3>
          <p>See your life journey</p>
        </div>
        <div class="tile">
          <i class="fas fa-users"></i>
          <h3>Shared With You</h3>
          <p>3 new memories</p>
        </div>
        <div class="tile">
          <i class="fas fa-hourglass-half"></i>
          <h3>Future Messages</h3>
          <p>2 locked until 2030</p>
        </div>
        <div class="tile">
          <i class="fas fa-chart-line"></i>
          <h3>Your Stats</h3>
          <p>47 memories preserved</p>
        </div>
      </div>

      <h3 style="margin-top: 2.5rem; color: var(--deep-blue);">Recent Memories</h3>
      <div class="memories-preview">
        <div class="memory-card-mini">
          <i class="fas fa-mountain"></i>
          <div>
            <h4>Summit Sunrise</h4>
            <p>Aug 12, 2024</p>
          </div>
        </div>
        <div class="memory-card-mini">
          <i class="fas fa-birthday-cake"></i>
          <div>
            <h4>30th Birthday</h4>
            <p>May 20, 2025</p>
          </div>
        </div>
        <div class="memory-card-mini">
          <i class="fas fa-music"></i>
          <div>
            <h4>First Concert</h4>
            <p>Feb 3, 2023</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <footer>
    <p>ETERNA — Where moments last forever.</p>
    <div class="footer-links">
      <a href="about.php">About</a>
      <a href="Team.php">Our Team</a>
      <a href="help.php">Help</a>
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
    </div>
  </footer>

  <script src="../js_files/eterna.js"></script>
</body>
</html>
